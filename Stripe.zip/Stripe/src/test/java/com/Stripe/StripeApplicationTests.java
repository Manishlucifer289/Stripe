package com.Stripe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripeApplicationTests {

	@Test
	void contextLoads() {
	}

}
